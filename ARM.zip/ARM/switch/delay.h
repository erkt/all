void delay(unsigned int i){
unsigned int j;
for(;i>0;i--)
	for(j=12000;j>0;j--);
}
