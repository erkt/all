void delay(unsigned short int i){
	unsigned short int j;
      	for(;i>0;i--)
		for(j=12000;j>0;j--);
}
