#!/usr/bin/python

from __future__ import printfun

for i in range(1,100,2):
	print (i," ")

print ()


