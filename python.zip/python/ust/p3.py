#!/usr/bin/python

sqr=lambda(x,y:x*x,y*y)

print sqr(3,4)
