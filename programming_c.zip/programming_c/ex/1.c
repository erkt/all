
/*myfunc ( struct test *t) {
strcpy(t.s, "world");
}*/
main( ) {
/*struct test { char s[10]; } t;
strcpy(t.s, "Hello");
printf("%s", t.s);
myfunc(t);
printf("%s", t.s);
*/
//printf("%-3f\n",123.45);

/*
for (i=getchar();; i=get.char())
if (i==‘x’) break;
else putchar(i); 
*/



printf("%–10s\n", "ABDUL"); 
}

