#include<stdio.h>
typedef struct binar{
int n;
 struct binar *left,*right;
}tree;
main(){
tree *hp=0;
char ch;
int n;
do{
	scanf("%d",&n);
	


}
