#include<stdio.h>
main(){
const volatile int l;
volatile int const j=90;
printf("%d\n",++l);
}
