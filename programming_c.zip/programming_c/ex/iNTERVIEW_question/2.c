#include<stdio.h>
       main()
       {
		int a=-12,b=-12,c=-12,d=-12;
		a=a>>1;
		b=b>>2;
		c=c>>3;
		d=d>>4;
		printf("%d %d %d %d\n",a,b,c,d);
       }
