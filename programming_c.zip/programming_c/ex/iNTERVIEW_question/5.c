#include<stdio.h>
       main()
       {
		int a=5,b=6;
		int max;
		a>b?max=a:max=b;
		printf("max=%d\n",max);
       }
