#include<stdio.h>
#define max 10
main(){
/*char c=125;
c=c+10;
char ch=255.0;
printf("%d\n",sizeof(ch++));
*
if(2/max value==5){
}
*/
float f=5.2;
if(f==5.2)
printf("===\n");
else if (f<5.2)
printf("%f   %lf <\n",f,5.2);
else
printf(">\n");
}
