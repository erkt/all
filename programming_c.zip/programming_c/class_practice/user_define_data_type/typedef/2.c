#include<stdio.h>
typedef int a[5];
main()
{
int i;
a b;
printf("DATA::");
for(i=0;i<5;i++)
	scanf("%d",&b[i]);
for(i=0;i<5;i++)
	printf("%d----",b[i]);
}

