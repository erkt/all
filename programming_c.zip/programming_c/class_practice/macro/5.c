#define BIG(a,b) if(a>b)printf("%d",a);else printf("%d",b);
main()//dsfnkjdfbjkhgkfdhb
{
int i=30,j=55;
BIG(i,j)
}
///dfngdjfhjkdhjkdhgjdkghdmnsghghbdskvgd
