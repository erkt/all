#include<stdio.h>
#define abc int
main()
{
abc j=10,k=20,l=33;
printf("%d %d %d\n",j,k,l);
}
