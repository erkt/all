#define a(m,n) m##n
main()
{
a(10,20);
}

