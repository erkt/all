#define sum(a,b) a+b
main()
{
int i=10,j=30,k;
k=sum(i,j);
printf("%d",k);
}
