#include<stdio.h>
int main()
{
/*int x = 0;
            int *ptr = &5;
            printf("%p\n", ptr);
*/
/*int x = 10;
	int const * const p;
	p = &x;
	printf("%d\n", *p);

	int const *p = 5;
	int q;
	p = &q;
	printf("%d",++(*p));
*/


/*	int x=256; char *p=&x;*++p=2;printf("%d",x);
*/
/*int x = 300;
	if(*(char *)&x == 44)
	printf("Little Endian\n");
	else
	printf("Big Endian\n");
*/



/*int x=-300;unsigned char *p;p=&x;
printf("%d\n",*p++);
printf("%d\n",*p);
*/


/*
int *ptr,a=10;
ptr=&a;*ptr+=1;printf("%d,%d/n",*ptr,a);
*/

/*int *p=10;
printf("%u\n",(unsigned int)p);
printf("%d\n",*p);
*/
}

