#include<stdio.h>
#include<stdlib.h>
main()
{
char c[]="123456";
int i;
i=atoi(c);
printf("i::%d    s::%s\n",i,c);
}
