#include<stdio.h>
main()
{
int j=1;
while(j!=20)
{
printf("***\n");
j++;
}
printf("?????\n");

}

