////////pattern////
#include<stdio.h>
main()
{
	int i,j,k;
	for (j=55555;j>0;j--)
	{
		for (i=j;i<4;i++)
			printf("* ");
		printf("\n");
	}
}
