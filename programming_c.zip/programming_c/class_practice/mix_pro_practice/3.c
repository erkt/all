#include<stdio.h>
main()
{
int interstpaid;
int AVERAGE;
int Name;
int FLOAT;
}

