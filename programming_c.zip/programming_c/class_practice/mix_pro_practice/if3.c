
/// enter marks n check fail n respective grade
#include<stdio.h>
main()
{
int 
}
