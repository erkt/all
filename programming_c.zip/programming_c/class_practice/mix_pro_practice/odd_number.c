#include<stdio.h>
main()
{
int i,j,k,m,l;
for (i=50;i<=100;i++)
{
if(i>>0&1)
printf("%d ",i);
}
}

