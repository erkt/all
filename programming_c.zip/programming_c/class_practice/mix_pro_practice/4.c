#include<stdio.h>
main()
{

int a=35,b=45;
printf("%d\n",sizeof(int));



}
