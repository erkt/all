#include<stdio.h>
main()
{
printf("a=====\a");
printf("b=====\b");
printf("t=====\t");
printf("nn====\n");
}
