


//    0 1 1 2 3 5 8 13 21 34.......
#include<stdio.h>
main()
{
int a,b,c,d,f,g,i;
printf("enter the 1st nu...");
scanf("%d",&a);
printf("enter the 2nd nu...");
scanf("%d",&b);

c=a+b;




for(i=0;i<=10;i++)
{
d=c;
f=d+c;


printf("%d ",f);
}




}
