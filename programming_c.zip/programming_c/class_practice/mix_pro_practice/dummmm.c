#include<stdio.h>
main()
{
char ch=500;
printf("%d",ch);
}
