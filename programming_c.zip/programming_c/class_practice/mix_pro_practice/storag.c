#include<stdio.h>
int *abc(void);
main()
{
static		int a;
}

/*
	int *p;
	p=abc();
	*p=30;
	printf("hello world\n");
	printf("%d\n",*p);
}
int *abc(void)
{
	int i;
	return &i;
}
*/
