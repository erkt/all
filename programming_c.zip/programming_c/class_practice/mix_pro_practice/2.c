#include<stdio.h>
main()
{
char k[55];
printf("enter char=\n",k);
scanf("%s",k);
printf("cha=%s\n",k);

}


