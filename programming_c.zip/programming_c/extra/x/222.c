#include<stdio.h>
int main(){
char *p;
printf("Enter the data::\n");
scanf("%s",p);
printf("Data::%d\n",p);
}
