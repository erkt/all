//#include<stdio.h>
#define com SLASH(/)
#define SLASH(s) /##s
main()
{
com printf("hfgh\n");
printf("hhh");
}
