#include<stdio.h>
main()
{
//char p[7]="vector";
char *p="vector";
if(p=="vector")
printf("-----\n");
else
printf("right\n");
}
