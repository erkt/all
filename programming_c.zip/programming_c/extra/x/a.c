#include<stdio.h>
main()
{

printf("main1111::::%u \n",main);
while(1);



}

