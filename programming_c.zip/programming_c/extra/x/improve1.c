//#include<stdio.h>
#define s(x) x*x
int main(){
float s1=10,u=30,t=2,a;
a=2*(s1-u*t)/s(t);
printf("%f\n",a);
}
