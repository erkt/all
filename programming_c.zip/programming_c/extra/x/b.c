#include<stdio.h>
main()
{



printf("%u\n",main);

}
