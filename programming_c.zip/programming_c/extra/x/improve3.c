//include<stdio.h>
//#define s(p,n,r) float si;si=p*n*r/100;
#define s(p,n,r) si=p*n*r/100;
int main(){
float p=2500,r=3.5;
int n=3;
float si;
s(p,n,r);
s(1500,2,2.5);
return 0;
}
