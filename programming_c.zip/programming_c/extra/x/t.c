#include<stdio.h>
main()
{
int a=10;
char f();
a=f();
printf("%d",a);
}
char f()
{
int c=0;

int b=55;
int d;
d=c+b;
printf("Haii\n");
c++;
}

