#include<stdio.h>
main()
{
int i;
	printf("hllooo");
//	scanf("%d",&i);
//	fflush(stdout);
	while(1);
}
