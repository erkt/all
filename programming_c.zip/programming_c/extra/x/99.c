#include<stdio.h>
int main(){
printf("nhgdfhg\n");
printf("jhxdg\n");
}
