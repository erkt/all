#include<stdio.h>
int main(){
int i=9;
switch(i)
{
printf("----\n");
case 9: printf("abc");
	break;
default:
	printf("xs\n");
}
}

