#include<stdio.h>
main()
{
int a=10,b;
float c=34.89;
b=a;
printf("a:%d b:%d f:%f\n",a,b,c);
b=c;
printf("a:%d b:%d f:%f\n",a,b,c);
}
