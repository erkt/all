#include<stdio.h>
int main(){
char ch;

while(1){

scanf("%d",&ch);
printf("%c",ch);
}

}
