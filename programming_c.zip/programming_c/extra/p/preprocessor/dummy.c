/#         include      "stdio.h"
#  /*sdgfhsfghsvghj*/ include   <stdlib.h>
# //include<string.h>
#define abc ABC;
main()
{
printf("Hiiiiii\n");
}
