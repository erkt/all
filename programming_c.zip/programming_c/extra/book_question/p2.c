typedef int INT;
int  i=20,j=30;
