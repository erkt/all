#include<stdio.h>
typedef int INT;
INT i,j;
//int i,j;
main()
{
printf("%d  %d\n",i,j);
}
