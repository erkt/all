#include<stdio.h>
main()
{
int i;
scanf("%3d",&i);
printf("%d\n",i);
}
