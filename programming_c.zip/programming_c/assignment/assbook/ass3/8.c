///values of result if x=50,y-75 and z=100????

#include<stdio.h>
main()
{
int x=50,y=75,z=100,result;
result=(x+50?y>=75?z>100?1:2:3:4);
printf("%d",result);



}

