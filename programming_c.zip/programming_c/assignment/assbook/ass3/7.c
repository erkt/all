/////assignment 3 prac 7 output of following 

#include<stdio.h>
main()
{
int x=0xFF;
printf("%d",x<<2);
}

