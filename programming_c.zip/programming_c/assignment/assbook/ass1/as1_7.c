//as1 book1 no 7 read a nu fm keybord show ASCII
#include<stdio.h>
main()
{

while(1)
{int a;
printf("enter number=");
scanf("%d",&a);
printf("\nnu eq to ASCII   %c\n",a);
}

}
 
