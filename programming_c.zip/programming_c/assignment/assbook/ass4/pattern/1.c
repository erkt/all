  /*      * * * * * 
	  * * * *
          * * * 
          * * 
          *
 */
#include<stdio.h>
main()
{

int i,j,a;

printf("enter the number...");
scanf("%d",&a);

for (i=0;i<a;i++)
{
for(j=i;j<a;j++)
printf("* ");
printf("\n");

}
}
