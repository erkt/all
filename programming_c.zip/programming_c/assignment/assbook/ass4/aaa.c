#include<stdio.h>
main()
{
int i;
for (i=1;i<=5;printf("%d",i));
i++;












/*int i=0;
for(;i;)
printf("mngj");
*/
}
