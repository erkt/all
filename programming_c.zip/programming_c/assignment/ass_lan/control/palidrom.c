//////////palidrom
#include<stdio.h>
main()

{
char ch[100];
printf("enter the string...");
scanf("%s",ch);
printf("%s\n",ch);
}
