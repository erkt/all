#include<iostream>
using namespace std;
class a{

public:
a operator +(a &b){

}
};
main(){
a v,v1,v2;
v2=v1+v;


}

