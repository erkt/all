#include<iostream>
using namespace std;
struct st{
	int i;
	float f;
}v{90,98.989};
int main(){
cout<<v<< endl;
}
