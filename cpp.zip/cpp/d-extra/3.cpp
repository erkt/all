#include<iostream>
using namespace std;
int main(){
	cout<<"jsgfjh"<<endl<<		cout<<"\t"<<		cout<<"\t"<<		cout<<endl;

	cout<<endl<<"55jsgfjh"<<endl<<
/*		cout<<"\t"<<
		cout<<"\t"<<
*/		cout<<endl;

	cout<<endl<<"shfdhfghfhgfjh"<<endl<<
/*		cout<<"\t"<
		cout<<"\t"<<
*/		cout<<endl;
}
