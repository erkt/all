#include<iostream>
#include<cstring>
using namespace std;
int main(){
string str,str1="sgdfhj";
//cin >> str;
getline(cin,str);
cout<< "Sizeof str  "<< sizeof(str)<<endl;
cout<< "Sizeof str1  "<< sizeof(str1)<<endl;
}

