#include<iostream>
using namespace std;
class A{
public:
A(){
cout<<" Co " << endl;
}
~A(){
cout<<" De " << endl;
}
};
int main(){
A obj;
}
