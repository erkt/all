#include<iostream>
using namespace std;
int main(){
int x=10,y=20;
cout<<" gdsfhdjhg  "<< x+y << 
  cout   <<endl;
}
