#include<iostream>
using namespace std;
int main(){
int x;
cin>> x;
cout<<"Dec:"<<x<<endl;
cout<<"Hex:"<<hex<<x<<endl;
cout<<"Oct:"<<oct<<x<<endl;
int y;
cin >>y;
cout<<dec;
cout<<"DATA:"<<y<<endl;//////////cout prefer last modification of( manipulate)data type means hex decimal octal etc....

}

