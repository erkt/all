#include<iostream>
using namespace std;
int main(){
int x;
cin>>x;
cout<<"helloworld"<<endl;
cout<<"data:"<<x<<endl;

}

