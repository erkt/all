namespace first{
int m=3000;
}
float add(float x,float y,int i,int j){
return x+y+i+j;
}
