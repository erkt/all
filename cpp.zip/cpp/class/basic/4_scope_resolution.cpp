#include<iostream>
using namespace std;
int x=100;
int main(){
int x;
cin>>x;
cout<<"X:"<<x<<endl;
cout<<"::X:"<<::x<<endl;
}

