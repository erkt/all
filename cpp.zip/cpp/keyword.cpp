#include<iostream>
using namespace std;
main(){
void short long int signed 
unsigned char float double auto
switch for if else  sizeof
while do break continue const 
static volatile extern register enum 
union  typedef struct return case 
goto default


delete  class   template try catch throw
public private protected bool using new 
namespace  this  inline mutable complex operator 
friend  typeid virtual explicit export false    
asm const_cast 
true
reinterpret_cast
dynamic_cast
static_cast
typename  wchar_t


}
