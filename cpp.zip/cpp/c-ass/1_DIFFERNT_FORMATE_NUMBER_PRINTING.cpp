#include<iostream>
using namespace std;
int main(){
int x;
cout<<"Enter decimal:"<<endl;
cin >> dec>>x;
cout<<"Dec:"<<x<<endl;
cout<<"Enter Hexadecimal( 0X____):"<<endl;
cin >> hex >>x;
cout<<"Hex:"<<hex<<x<<endl;
cout<<"Enter Octal( 0___):"<<endl;
cin >> oct >>x;
cout<<"Oct:"<<oct<<x<<endl<<dec;
}
